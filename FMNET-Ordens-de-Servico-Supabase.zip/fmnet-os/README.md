# FM NET — Ordens de Serviço (Supabase)

Esta versão substitui o SQLite por Supabase e mantém o HTML anterior, login admin, cadastro, listagem, status e impressão. **Não transfere automaticamente os dados do SQLite.**

1. No Supabase SQL Editor, execute `supabase-setup.sql` (cria a tabela `fmnet_sessions`, além da tabela de OS existente).
2. Extraia o ZIP em uma **nova pasta** para não apagar o sistema local antigo.
3. No CMD dentro de `fmnet-os`, execute `npm install`.
4. Copie `.env.example` para `.env` e ajuste `SESSION_SECRET` (32+ caracteres), `ADMIN_PASSWORD` (12+ caracteres), `SUPABASE_URL` e `SUPABASE_SECRET_KEY`. Use a chave `sb_secret_...` do Supabase, NUNCA a publishable `sb_publishable_...`. **Não compartilhe, não envie por chat e não faça upload do .env a um repositório.**
5. Deixe `NODE_ENV=development` somente em testes no localhost. Execute `npm start` e teste `http://localhost:3000`.
6. Na hospedagem Render, cadastre os mesmos segredos em **Environment Variables**, configure `NODE_ENV=production`, Build `npm install`, Start `npm start`; não publique o `.env`. O serviço gratuito pode adormecer e a versão gratuita do Supabase pode pausar por inatividade.

**Cuidados:** o projeto ainda requer revisão de dependências e segurança antes de uso comercial com informações pessoais; proteja a chave secret com acesso somente do servidor. Use HTTPS em produção. Sessões são salvas no Supabase para não dependerem do disco efêmero. O projeto lista no máximo as 1000 OS mais recentes; paginar depois, se necessário.
