-- Execute no SQL Editor do SEU projeto Supabase.
create table if not exists public.ordens_servico (
  id bigint generated always as identity primary key,
  name text not null,
  address text not null,
  phone text not null,
  description text not null default '',
  status text not null default 'Aberta' check(status in ('Aberta','Em andamento','Concluída')),
  created_at timestamptz not null default now()
);
alter table public.ordens_servico enable row level security;
revoke all on table public.ordens_servico from anon, authenticated;
revoke all on sequence public.ordens_servico_id_seq from anon, authenticated;

-- Sessões persistentes. Acesso exclusivo ao servidor com chave secreta.
create table if not exists public.fmnet_sessions (
  sid text primary key,
  sess jsonb not null,
  expires_at timestamptz not null
);
alter table public.fmnet_sessions enable row level security;
revoke all on table public.fmnet_sessions from anon, authenticated;
create index if not exists fmnet_sessions_expires_idx on public.fmnet_sessions(expires_at);
